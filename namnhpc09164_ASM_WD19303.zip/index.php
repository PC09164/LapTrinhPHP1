<?php

session_start();
require_once "vendor/autoload.php";

require_once "src/Views/index.php";

// var_dump($_SESSION['user']);
// var_dump(password_hash('123',1));