<?php


namespace App\Model;


use mysqli;
class Database
{
    private $_connection;

   

    public function __construct()
    {

        $server = "localhost";

        $db_username = "root";

        // password:
        // AMPPS = mysql, XAMPP= , MAMP= root , laragon= tu dat
        $db_password = "";

        $database = "php1_wd19303";

        $this->_connection = new mysqli(
            $server,
            $db_username,
            $db_password,
            $database
        );
        
    }
    public function query(string $query){
        return $this->_connection->query($query);
    }

    public function prepare(string $query)
    {
        return $this->_connection->prepare($query);
    }


}
