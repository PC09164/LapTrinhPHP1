<?php

namespace App\Model;

use App\Model\Database;

class Department extends Database implements CrudInterface
{

    public function __construct()
    {
        parent::__construct();
    }
    public function getAll()
    {
        $query = "SELECT * FROM `pc09164_departments`";
        $result = $this->query($query);
        return $result;
    }

    public function getOne(int $id)
    {
        $query = "SELECT `id` FROM `pc09164_departments`";
        $result = $this->query($query);
        return $result;
    }

    // update, create, delete;
    // can data de them
    public function update(int $id, array $data)
    {
        $name = $data['name'] ?? '';
        $status = $data['status'] == 'on' ? 1 : 0;
        $query = "UPDATE `pc09164_departments` SET `name`='$name', `status`='$status' WHERE `id` = '$id'";  
        $result = $this->query($query);
        return $result;
    }

    public function create(array $data)
    {
        $status = $data['status'] == 'on' ? 1 : 0;
        $name = $data['name'] ?? '';
        $query = "INSERT INTO `pc09164_departments`( `name`, `status`) 
        VALUES ('$name','$status')"; // them code insert into department
        $result = $this->query($query);
        return $result;
    }
  



    public function delete(int $id): bool
    {
        $query = "DELETE FROM `pc09164_departments` WHERE `id` = '$id'";
        $result = $this->query($query);
        return $result;
    }
}

