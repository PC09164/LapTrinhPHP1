<?php

namespace App\Model;

use App\Model\Database;

class Employee extends Database implements CrudInterface
{

    public function __construct()
    {
        parent::__construct();
    }
    public function getAll()
    {
        $query = "SELECT * FROM `pc09164_emplyees`";
        $result = $this->query($query);
        return $result;
    }

    public function getOne(int $id)
    {
        $query = "SELECT `code` FROM `pc09164_emplyees`";
        $result = $this->query($query);
        return $result;
    }

    // update, create, delete;
    // can data de them
    public function update(int $id, array $data)
    {
        $firstname = $data['firstname'] ?? '';
        $lastname = $data['lastname'] ?? '';
        $code = $data['code'] ?? '';
        $department_id = $data['department_id'] ?? '';
        $query = "UPDATE `pc09164_emplyees` SET `firstname`='$firstname', `lastname`='$lastname',`code`='$code',`department_id`='$department_id'
        WHERE `id` = '$id'";
        $result = $this->query($query);
        return $result;
    }

    public function create(array $data)
    {
        $firstname = $data['firstname'] ?? '';
        $lastname = $data['lastname'] ?? '';
        $code = $data['code'] ?? '';
        $department_id = $data['department_id'] ?? '';
        $query = "INSERT INTO `pc09164_emplyees`( `firstname`, `lastname`,`code`,`department_id`) 
        VALUES ('$firstname','$lastname','$code', '$department_id')"; // them code insert into department
        $result = $this->query($query);
        return $result;
    }



    public function delete(int $id): bool
    {
        $query = "DELETE FROM `pc09164_emplyees` WHERE `id` = '$id'";
        $result = $this->query($query);
        return $result;
    }
}
