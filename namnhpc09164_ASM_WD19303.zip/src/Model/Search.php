<?php


namespace App\Model;

use App\Model\Database;

class Department extends Database
{
    
}