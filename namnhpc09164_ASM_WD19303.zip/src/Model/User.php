<?php


namespace App\Model;


class User extends Database{

    protected $table = "pc09164_users";

    public function __construct()
    {
        parent::__construct();
    }

    //sql injection

    public function login($email, $password)
    {
        $sql = "SELECT * FROM $this->table WHERE `email` = ?";

        $stmt = $this->prepare($sql);

        $stmt->bind_param('s', $email);

        $stmt->execute();

        $result = $stmt->get_result();

        // var_dump($result);
        $data = $result->fetch_assoc();
        // var_dump($data);
        //cách mã hóa mật khẩu
        // echo password_hash('123',1);
        // echo 'Password vừa nhập:'. $password;
        // echo "<hr> Password đã mã hóa trước đó". $data['password'];
        if($data !== NULL && password_verify($password, $data['password'])){
            return $data;
        }else{
            return [];
        }
       
    }

    public function register($email, $password, $name, $avatar){
        $sql = "INSERT INTO $this->table (`email`, `password`, `name`, `avatar`) VALUES(?, ?, ?, ?)";

        $stmt = $this->prepare($sql);

        $newPassword = password_hash($password,PASSWORD_BCRYPT);

        $stmt->bind_param('ssss', $email, $newPassword, $name, $avatar);

        $stmt->execute();

        $result = $stmt->get_result();

        var_dump($result);
        // $data = $result->fetch_assoc();
        // var_dump($data);
        // if(password_verify($password, $data['password'])){
        //     return "Đăng nhập thành công!";
        // }else{
        //     return "Đăng nhập thất bại!";
        // }


    }

    public function updatePassword($email, $password){
        
        $sql = "UPDATE $this->table SET `password` = ? WHERE `email` = ?";

        $stmt = $this->prepare($sql);

        $new_password = password_hash($password, PASSWORD_BCRYPT);

        $stmt->bind_param('ss',$new_password, $email);

        $stmt->execute();

        // $result = $stmt->get_result();

        // var_dump($result);
        // $data = $result->fetch_assoc();
        // var_dump($result);
        // var_dump($data);
        //cách mã hóa mật khẩu
        // echo password_hash('123',1);
        // echo 'Password vừa nhập:'. $password;
        // echo "<hr> Password đã mã hóa trước đó". $data['password'];
        // if($data == NULL && password_verify($password, $data['password'])){
        //     return $data;
        // }else{
        //     return [];
        // }
       
    }

    public function updateInfo($email, $name, $avatarPath)
    {
        $sql = "UPDATE $this->table SET `name` = ?, `avatar` = ? WHERE `email` = ?";
        $stmt = $this->prepare($sql);
        $stmt->bind_param('sss', $name, $avatarPath, $email);
        $stmt->execute();

        return $stmt->affected_rows > 0;
    }
}