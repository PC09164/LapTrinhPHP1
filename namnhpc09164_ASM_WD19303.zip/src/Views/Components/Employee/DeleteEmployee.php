<?php


namespace App\Views\Components\Employee;

use App\Model\Employee;

use App\Views\BaseView;

class DeleteEmployee extends BaseView
{

    public static function render()
    {
    }

    public static function handle()
    {
        // echo "Delete successfully";
        $id = $_GET['id'];
        $employee = new Employee();
        $employee->delete($id);
        header('Location:?act=danhsachnhanvien');
    }
}
