<?php

namespace App\Views\Components\Employee;

use App\Model\Employee;

use App\Views\BaseView;

class AddEmployee extends BaseView
{


    public static function render()
    {
?>

        <div class="container">
            <div class="card">
                <div class="card-header">
                    THEM NHÂN VIÊN
                </div>
                <div class="card-body">
                    <form method="POST" action="?act=xulythemnhanvien">
                        <div class="mb-3">
                            <label for="firstname">FirstName: </label>
                            <input type="text" name="firstname" id="firstname" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label for="lastName">LastName: </label>
                            <input type="text" name="lastname" id="lastName" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label for="code">Code: </label>
                            <input type="text" name="code" id="code" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label for="department_id">DepartmentID: </label>
                            <input type="text" name="department_id" id="department_id" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label for="click"></label>
                            <input type="checkbox" name="click" id="click">
                            Kich hoat
                        </div>
                        <button type="submit" class="btn btn-primary">
                            Thêm Nhân Viên
                        </button>
                    </form>
                </div>
            </div>
        </div>
<?php
    }
    public static function handle()
    {
        $data = $_POST;
        // var_dump($data);
        // tiep tuc xu ly database
        $employee = new Employee();
        $result = $employee->create($data);

        if ($result) {
            header("Location: ?act=danhsachnhanvien");
        }
    }
}
