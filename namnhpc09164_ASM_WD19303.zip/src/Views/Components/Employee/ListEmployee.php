<?php

namespace App\Views\Components\Employee;

use App\Views\BaseView;
use App\Model\Employee;


class ListEmployee extends BaseView
{
    public static function render()
    {
        $employee = new Employee();
        $records = $employee->getAll();
?>
        <div class="container">
            <div class="card">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">FirstName</th>
                            <th scope="col">LastName</th>
                            <th scope="col">Code</th>
                            <th scope="col">DepartmentID</th>
                            <th scope="col">Operations</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($records->num_rows > 0) : ?>
                            <?php while ($record = $records->fetch_assoc()) : ?>
                                <tr>
                                    <th scope="rows"><?= $record['id'] ?> </th>
                                    <td><?= htmlspecialchars($record['firstname']) ?></td>
                                    <td><?= htmlspecialchars($record['lastname']) ?></td>
                                    <td><?= htmlspecialchars($record['code']) ?></td>
                                    <td><?= htmlspecialchars($record['department_id']) ?></td>
                                    <td><button class="btn btn-primary"><a href="?act=updateemployee&id=<?= $record['id'] ?>" class="text-light">Update</a></button>
                                        <button class="btn btn-danger "><a href="?act=deleteemployee&id=<?= $record['id'] ?>" class="text-light">Delete</a></button>
                                    </td>
                                </tr>

                            <?php endwhile; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="4">No records found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
<?php
    }
    public static function handle()
    {
    }
}
