<?php


namespace App\Views\Components\Employee;

use App\Model\Employee;

use App\Views\BaseView;

class EditEmployee extends BaseView
{

    public static function render()
    {
        $id = $_GET['id'];
?>
        <!-- <form class="d-flex my-2 my-lg-0">
                <input class="form-control me-sm-2" type="text" placeholder="Search" />
                <button class="btn btn-outline-success my-2 my-sm-0" type="submit">
                    Search
                </button>
            </form> -->
        <div class="container">
            <div class="card">
                <div class="card-header">
                    UPDATE DEPARTMENT
                </div>
                <div class="card-body">
                    <form method="POST" action="?act=xulycapnhatnhanvien&&id=<?=$id?>">
                        <div class="mb-3">
                            <label for="firtname">Firtname</label>
                            <input type="text" name="firtname" id="firtname" class="form-control">
                            <label for="lastname">Lastname</label>
                            <input type="text" name="lastname" id="lastname" class="form-control">
                            <label for="code">Code</label>
                            <input type="text" name="code" id="code" class="form-control">
                            <label for="department_id">DepartmentID</label>
                            <input type="text" name="department_id" id="department_id" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label for="status"></label>
                            <input type="checkbox" name="status" id="status">
                            Kich hoạt
                        </div>
                        <button type="submit" class="btn btn-primary">
                            Cập nhật
                        </button>
                    </form>

                </div>
            </div>
        </div>

<?php
    }
    public static function handle()
    {
        ?> 
        
        <?php
        $id = $_GET["id"];
        // var_dump($id) . "<br/>";
        $data = $_POST;
        // var_dump($data);
        $department = new Employee();
        $result = $department->update($id, $data);
        var_dump($result);
        if ($result) {
            header("Location:?act=danhsachnhanvien");
        }
    }
}
