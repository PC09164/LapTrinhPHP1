<?php



namespace App\Views\Components;

use App\Views\BaseView;

class Header extends BaseView
{

    public static function render()
    { ?>
        <nav class="navbar navbar-expand-sm">
            <div class="container">
                <a class="navbar-brand" href="#">PC09164</a>
                <button class="navbar-toggler d-lg-none" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="collapsibleNavId">
                    <ul class="navbar-nav me-auto mt-2 mt-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="?act=home" aria-current="page">Home
                                <span class="visually-hidden">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link " href="?act=danhsachnhanvien" >ListEmployee</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="?act=themnhanvien">AddEmployee</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link " href="?act=danhsachphong" >ListDepartment</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link " href="?act=themphong" >AddDepartment</a>
                        </li>
                        <div class="d-flex align-items-center">
                        <?php if (!empty($_SESSION['user'])) : ?>
                            <a class="nav-link" href="?act=account">
                                <i class="fas fa-user"></i>
                                Hello, <?= $_SESSION['user']['name'] ?>
                            </a>
                            <a class="nav-link" href="?act=logout"> <i class="fas fa-sign-out-alt"></i> Đăng xuất</a>
                        <?php else : ?>
                            <a class="nav-link" href="?act=account">
                                <i class="fas fa-user"></i> Tài khoản
                            </a>
                        <?php endif; ?>
                    </div>
                    </ul>
                    <form class="d-flex my-2 my-lg-0">
                        <input class="form-control me-sm-2" id="search" type="text" placeholder="Search" />
                        <button class="btn btn-outline-success my-2 my-sm-0" id="btn-search" type="submit">
                            Search
                        </button>
                    </form>
                </div>
            </div>
        </nav>


<?php }
    public static function handle(){
        
    }
}
