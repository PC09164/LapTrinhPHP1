<?php


namespace App\Views\Components\Search;

use App\Views\BaseView;

class Search extends BaseView
{
    public static function render()
    {
?>
        <div class="container">
            <div class="card-body">
                <form method="POST" action="?act=searchdata">
                    <div class="mb-3">
                        <input type="text" name="search data" id="search data" class="form-control" placeholder="Search">
                    </div>
                    <button type="submit" class="btn btn-primary">
                        Tìm kiếm
                    </button>
                </form>
            </div>
        </div>
<?php
    }

    public static function handle()
    {
        if(isset($_POST)){
            
        }
    }
}
