<?php


namespace App\Views\Components\Department;

use App\Model\Department;
use App\Views\BaseView;

class AddDepartment extends BaseView{

    public static function render(){


        // dong tren se xu ly du lieu
        // viet code html css o duoi
        ?>

            <div class="container">
                <div class="card">
                    <div class="card-header">
                        THEM PHONG BAN
                    </div>
                    <div class="card-body">
                        <form method="POST" action="?act=xulythemphong">
                            <div class="mb-3">
                                <label for="name">Ten phong</label>
                                <input type="text" name="name" id="name" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label for="status"></label>
                                <input type="checkbox" name="status" id="status">
                                Kich hoat
                            </div>
                            <button type="submit" class="btn btn-primary">
                                Luu lai
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        <?php 
    }
    public static function handle(){
        $data= $_POST;
        // var_dump($data);
        // tiep tuc xu ly database
        $department=new Department();
        $result=$department->create($data);
        
        if ($result){
            header("Location: ?act=danhsachphong");
        }
    }
}