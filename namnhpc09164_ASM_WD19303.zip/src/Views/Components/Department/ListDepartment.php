<?php


namespace App\Views\Components\Department;

use App\Model\Department;

use App\Views\BaseView;

class ListDepartment extends BaseView
{

    public static function render()
    {
        $department = new Department();
        $records = $department->getAll();
?>
        <div class="container">
            </form>
            <div class="card">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">DepartmentID</th>
                            <th scope="col">NameDepartment</th>
                            <th scope="col">Status</th>
                            <th scope="col-2">Operations</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($records->num_rows > 0) : ?>
                            <?php while ($record = $records->fetch_assoc()) : ?>
                                <tr>
                                    <th scope="rows"><?= $record['id'] ?> </th>
                                    <td><?= htmlspecialchars($record['name']) ?></td>
                                    <td><?= $record['status'] == 1 ? 'Active' : 'Inactive' ?></td>
                                    <td><button class="btn btn-primary"><a href="?act=updatedepartment&id=<?= $record['id']?>" class="text-light">Update</a></button>
                                    <button class="btn btn-danger "><a href="?act=deletedepartment&id=<?= $record['id']?>" class="text-light">Delete</a></button></td>
                                </tr>

                            <?php endwhile; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="4">No records found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
<?php
    }

    public static function handle()
    {
    }
}
