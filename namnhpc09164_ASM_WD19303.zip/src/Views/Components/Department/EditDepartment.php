<?php


namespace App\Views\Components\Department;

use App\Model\Department;

use App\Views\BaseView;

class EditDepartment extends BaseView
{

    public static function render()
    {
        $id = $_GET['id'];
?>
        <!-- <form class="d-flex my-2 my-lg-0">
                <input class="form-control me-sm-2" type="text" placeholder="Search" />
                <button class="btn btn-outline-success my-2 my-sm-0" type="submit">
                    Search
                </button>
            </form> -->
        <div class="container">
            <div class="card">
                <div class="card-header">
                    UPDATE DEPARTMENT
                </div>
                <div class="card-body">
                    <form method="POST" action="?act=xulycapnhatphong&&id=<?=$id?>">
                        <div class="mb-3">
                            <label for="name">Tên phòng</label>
                            <input type="text" name="name" id="name" class="form-control">
                            <label for="status">Trạng thái</label>
                            <input type="text" name="status" id="status" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label for="status"></label>
                            <input type="checkbox" name="status" id="status">
                            Kich hoạt
                        </div>
                        <button type="submit" class="btn btn-primary">
                            Cập nhật
                        </button>
                    </form>

                </div>
            </div>
        </div>

<?php
    }
    public static function handle()
    {
        ?> 
        
        <?php
        $id = $_GET["id"];
        // var_dump($id) . "<br/>";
        $data = $_POST;
        // var_dump($data);
        $department = new Department();
        $result = $department->update($id, $data);
        var_dump($result);
        if ($result) {
            header("Location:?act=danhsachphong");
        }
    }
}
