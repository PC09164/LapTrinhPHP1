<?php


namespace App\Views\Components\Department;

use App\Model\Department;

use App\Views\BaseView;

class DeleteDepartment extends BaseView
{

    public static function render()
    {
    }

    public static function handle()
    {
        // echo "Delete successfully";
        $id = $_GET['id'];
        $department = new Department();
        $department->delete($id);
        header('Location:?act=danhsachphong');
    }
}
