<?php


namespace App\Views\Components\Account;

use App\Views\BaseView;

class UpdateAccount extends BaseView{
    public static function render(){

    }

    public static function handle(){
        
    }
}
