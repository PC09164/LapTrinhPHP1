<?php


namespace App\Views\Components\Account;

use App\Views\BaseView;
use App\Model\User;

class Account extends BaseView
{
    public static function render()
    {
        if (!empty($_SESSION['user'])) {
            self::updateAccount();
        } else {
            self::form();
        }
    }


    public static function login()
    {
        $email = $_POST['email'];
        $password = $_POST['password'];
        $account = new User();
        $data = $account->login($email, $password);
        if (!empty($data)) {
            //lưu session
            $_SESSION['user'] = $data;
        }
        // header("Location: ?act=account");
    }

    public static function register()
    {
        $email = $_POST['email'];
        $password = $_POST['password'];
        $name = $_POST['name'];
        $avatar = $_POST['avatar'];
        $register = new User();
        $register->register($email, $password, $name, $avatar);
    }

    public static function form()
    {
?>
        <div class="container">
            <div class="row">
                <div class="col-xl-6">
                    <div class="card-header">
                        <h1>Đăng nhập</h1>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="?act=login">
                            <div class="mb-3">
                                <label for="login_email">Email</label>
                                <input type="text" name="email" id="email" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label for="login_password">Mật khẩu</label>
                                <input type="password" name="password" id="password" class="form-control">
                            </div>
                            <div class="mb-3"><button type="submit" class="btn btn-primary">Login</button></div>
                        </form>
                    </div>
                </div>

                <div class="col-xl-6">
                    <div class="card-header">
                        <h1>Đăng ký</h1>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="?act=register">
                            <div class="mb-3">
                                <label for="signup_email">Email</label>
                                <input type="text" name="email" id="email" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label for="signup_password">Mật khẩu</label>
                                <input type="password" name="password" id="password" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label for="name">Họ và tên</label>
                                <input type="text" name="name" id="name" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label for="avatar">Hình ảnh</label>
                                <input type="file" name="avatar" id="avatar" class="form-control">
                            </div>
                            <div class="mb-3"><button type="submit" class="btn btn-primary">Sign Up</button></div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    <?php
    }

    public static function updateAccount()
    {
    ?>
        <div class="container">
            <div class="row">
                <div class="col-6">
                    <div class="card-header">
                        <h1>Đổi mật khẩu</h1>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="?act=updatePassword">
                            <div class="mb-3">
                                <label for="update_password">Mật khẩu hiện tại</label>
                                <input type="password" value="<?= $_SESSION['password']['old_password'] ?? '' ?>" name="old_password" id="update_password" class="form-control">
                                <p class="text-danger"><?= $_SESSION['password']['notify_old_password'] ?? '' ?></p>
                            </div>
                            <div class="mb-3">
                                <label for="update_password">Mật khẩu mới</label>
                                <input type="password" value="<?= $_SESSION['password']['new_password'] ?? '' ?>" name="new_password" id="update_password" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label for="update_password">Xác nhận mật khẩu</label>
                                <input type="password" value="<?= $_SESSION['password']['confirm_password'] ?? '' ?>" name="confirm_password" id="update_password" class="form-control">
                                <p class="text-danger"><?= $_SESSION['password']['notify_confirm_password'] ?? '' ?></p>
                            </div>
                            <div class="mb-3"><button type="submit" class="btn btn-primary">Đổi mật khẩu</button></div>
                        </form>
                    </div>
                </div>

                <div class="col-6">
                    <div class="card-header">
                        <h1>Cật nhật tài khoản </h1>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="?act=updateAccount" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="email">Email</label>
                                <input type="text" name="email" value="<?= $_SESSION['user']['email'] ?>" readonly id="email" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label for="new_name">Họ và tên</label>
                                <input type="text" name="new_name" value="<?= $_SESSION['user']['name'] ?>" id="new_name" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label for="new_avatar">Ảnh đại diện</label>
                                <input type="file" name="new_avatar" value="<?= $_SESSION['user']['avatar'] ?>" id="new_avatar" class="form-control">
                            </div>
                            <div class="mb-3"><button type="submit" class="btn btn-primary">Cật nhật</button></div>
                        </form>
                    </div>
                </div>
            </div>
    <?php
        unset($_SESSION['password']);
    }

    public static function updatePassword()
    {
        $old_password = $_POST['old_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];

        //thêm điều kiện
        //mật khẩu cũ trống

        // if (empty($_SESSION['password']['old_password'])) {
        //     //thông báo
        //     $_SESSION['password']['notify_old_password']  = "Vui lòng nhập mật khẩu";
        // }
        if ($confirm_password !== $new_password) {
            //bước 1, lưu mật khẩu cũ, và mật khẩu mới vào session
            $_SESSION['password']['old_password'] = $old_password;
            $_SESSION['password']['new_password'] = $new_password;
            $_SESSION['password']['confirm_password'] = $confirm_password;

            //bước 2, lưu thông báo vào session, in ra thông báo
            $_SESSION['password']['notify_confirm_password'] = "Xác nhận mật khẩu chưa đúng!";
            //bước 3, submit lại

            //bước 4, xóa session thông báo vừa in đi
            header("Location: ?act=account");
        } else {
            //truy cập vào database 
            //kiểm tra email hiện tại 
            //email hiện tại nằm session
            $email = $_SESSION['user']['email'];
            $password = $old_password;
            $account = new User();
            $data = $account->login($email, $password);
            // var_dump($data);
            if (!empty($data)) {

                //Xác thực thành công
                $account->updatePassword($email, $new_password);
            } else {
                //Mật khẩu cũ chưa đúng
                $_SESSION['password']['notify_old_password'] = "Mật khẩu cũ chưa đúng!";

                header("Location: ?act=account");
            }
        }
        header("Location: ?act=home");
    }




    public static function updateInfo()
    {

        //   var_dump($_POST);
        // $email = $_SESSION['user']['email'];
        // $name = $_POST['new_name'];
        // $avatar = $_FILES['name'];
        var_dump($_FILES);


        // if ($avatar['error'] === UPLOAD_ERR_OK) {
        //     $uploadDir = 'upload/';
        //     $new_avatar = $uploadDir . basename($avatar['name']);

        //     if (move_uploaded_file($avatar['tmp_name'], $new_avatar)) {
        //         $avatarPath = $new_avatar;
        //     } else {
        //         $avatarPath = $_SESSION['user']['avatar'];
        //     }
        // } else {
        //     $avatarPath = $_SESSION['user']['avatar'];
        // }
        // var_dump($new_avatar);

        // $account = new User();
        // if ($account->updateInfo($email, $name, $avatarPath)) {
        //     $_SESSION['update_success'] = true;
        //     $_SESSION['user']['name'] = $name;
        //     $_SESSION['user']['avatar'] = $avatarPath;
        // } else {
        //     $_SESSION['update_error'] = 'Lỗi khi cập nhật tài khoản.';
        // }

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            if (isset($_FILES['new_avatar']) && $_FILES['new_avatar']['error'] == 0) {
                $uploadDir = 'uploads/';
                $uploadFile = $uploadDir ."-". basename($_FILES['new_avatar']['name']);

                // Kiểm tra và di chuyển tệp tin đến thư mục đích
                if (move_uploaded_file($_FILES['new_avatar']['tmp_name'], $uploadFile)) {
                    // $avatarPath = $uploadFile;
                    echo"thành công";
                } else {
                    // $avatarPath = $_SESSION['user']['avatar'];
                    echo"Chưa thành công";
                }
            } else {
                echo"upload không thành công";
            }
        }
        // $account = new User();
        // if ($account->updateInfo($email, $name, $avatarPath)) {
        //     $_SESSION['update_success'] = true;
        //     $_SESSION['user']['name'] = $name;
        //     $_SESSION['user']['avatar'] = $avatarPath;
        // } else {
        //     $_SESSION['update_error'] = 'Lỗi khi cập nhật tài khoản.';
        // }

        // header('Location: ?act=account');
        // exit();
    }



    public static function handle()
    {
    }
}
