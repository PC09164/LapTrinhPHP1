<?php

namespace App\Views\Components;

use App\Views\BaseView;

class Sidebar extends BaseView
{

    public static function render()
    { ?>
        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4 " style="font-size: 20px;">
            <!-- Brand Logo -->
            <a href="#" class="brand-link">
                <span class="brand-text font-weight-bold">PC09164 - NamNH</span>
            </a>

            <!-- Sidebar -->
            <div class="sidebar">
                <!-- Sidebar user panel (optional) -->
                <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                    <div class="image">

                    </div>
                    <div class="info">
                        <a href="/?act=home" class="d-block"> <i class="bi bi-house-door" style="padding-right:10px;"></i>Home</a>
                    </div>


                </div>

                <!-- Sidebar Menu -->
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">
                        <!-- Add icons to the links using the .nav-icon class
             with font-awesome or any other icon font library -->

                        <li class="nav-item">
                            <a href="/?act=listemployee" class="nav-link">
                                <!-- <i class="far fa-circle nav-icon"></i> -->
                                <p> <i class="bi bi-person-vcard-fill" style="padding-right:10px;"></i>Nhân Viên</p>
                            </a>
                        </li>
                    </ul>
                    </li>

                    </ul>
                </nav>
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">
                        <!-- Add icons to the links using the .nav-icon class
             with font-awesome or any other icon font library -->

                        <li class="nav-item">
                            <a href="" class="nav-link">
                                <!-- <i class="far fa-circle nav-icon"></i> -->
                                <p><i class="bi bi-kanban" style="padding-right:10px;"></i>Quản lý dự án</p>
                            </a>
                        </li>
                    </ul>
                    </li>

                    </ul>
                </nav>
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">
                        <!-- Add icons to the links using the .nav-icon class
             with font-awesome or any other icon font library -->

                        <li class="nav-item">
                            <a href="" class="nav-link">
                                <!-- <i class="far fa-circle nav-icon"></i> -->
                                <p><i class="bi bi-bar-chart-fill" style="padding-right:10px;"></i>Hiệu suất</p>
                            </a>
                        </li>
                    </ul>
                    </li>

                    </ul>
                </nav>
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">
                        <!-- Add icons to the links using the .nav-icon class
             with font-awesome or any other icon font library -->

                        <li class="nav-item">
                            <a href="" class="nav-link">
                                <!-- <i class="far fa-circle nav-icon"></i> -->
                                <p><i class="bi bi-coin" style="padding-right:10px;"></i>Tài chính</p>
                            </a>
                        </li>
                    </ul>
                    </li>

                    </ul>
                </nav>
                <!-- /.sidebar-menu -->
            </div>
            <!-- /.sidebar -->
        </aside>

<?php }

    public static function handle()
    {
    }
}
