<?php

namespace App\Views\Components;

use App\Views\BaseView;
use App\Model\Employee;

class Home extends BaseView
{

    public static function render()
    { 
        $employee = new Employee();
        $records = $employee->getAll();
        ?>
        <!-- <div class="container">
            <h1>Hello</h1>
        </div> -->

        <div class="container text-center">
            <h1 style="margin: 30px;">Chào mừng trở lại, Nguyễn Hoàng Nam</h1>
            <div class="row align-items-center">
                <!-- <div class="col-2">

                </div> -->
                <div class="col-12">
                    <div class="" style="float:left;margin: 20px;">
                        <div class="info-box">
                            <span class="info-box-icon bg-info"><i class="far fa-bookmark"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text">Nhân viên</span>
                                <span class="info-box-number">100</span>
                                <div class="progress">
                                    <div class="progress-bar bg-info" style="width: 40%"></div>
                                </div>
                                <span class="progress-description">
                                    <button type="button" class="btn btn-primary">Hoạt động</button>
                                    <button type="button" class="btn btn-danger">Không hoạt động</button>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div style="float:left;margin: 20px;">
                        <div class="info-box bg-success">
                            <span class="info-box-icon"><i class="far fa-thumbs-up"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text">Tổng số dự án</span>
                                <span class="info-box-number">10</span>
                                <div class="progress">
                                    <div class="progress-bar" style="width: 20%"></div>
                                </div>
                                <span class="progress-description">
                                    <button type="button" class="btn btn-primary">Đang tiến hành</button>
                                    <button type="button" class="btn btn-danger">Đã hoàn tất</button>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div style="float:left;margin: 20px;">
                        <div class="info-box bg-gradient-warning">
                            <span class="info-box-icon"><i class="far fa-calendar-alt"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text">Công việc</span>
                                <span class="info-box-number">10</span>
                                <div class="progress">
                                    <div class="progress-bar" style="width: 20%"></div>
                                </div>
                                <span class="progress-description">
                                    <button type="button" class="btn btn-primary">Đang tiến hành</button>
                                    <button type="button" class="btn btn-danger">Đã hoàn tất</button>
                                </span>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="col-2">

                    </div> -->
                </div>
            </div>
            <div class="container">
                <div class="card">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">FirstName</th>
                                <th scope="col">LastName</th>
                                <th scope="col">Code</th>
                                <th scope="col">DepartmentID</th>
                                <th scope="col">Operations</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($records->num_rows > 0) : ?>
                                <?php while ($record = $records->fetch_assoc()) : ?>
                                    <tr>
                                        <th scope="rows"><?= $record['id'] ?> </th>
                                        <td><?= htmlspecialchars($record['firstname']) ?></td>
                                        <td><?= htmlspecialchars($record['lastname']) ?></td>
                                        <td><?= htmlspecialchars($record['code']) ?></td>
                                        <td><?= htmlspecialchars($record['department_id']) ?></td>
                                        <td><button class="btn btn-primary"><a href="?act=updateemployee&id=<?= $record['id'] ?>" class="text-light">Update</a></button>
                                            <button class="btn btn-danger "><a href="?act=deleteemployee&id=<?= $record['id'] ?>" class="text-light">Delete</a></button>
                                        </td>
                                    </tr>

                                <?php endwhile; ?>
                            <?php else : ?>
                                <tr>
                                    <td colspan="4">No records found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>


    <?php }


    public static function handle()
    {
    }
}
