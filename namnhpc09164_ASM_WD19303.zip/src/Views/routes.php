<?php

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

use App\Views\Components\Header;
use App\Views\Components\Footer;
use App\Views\Components\Home;
use App\Views\Components\Sidebar;
use App\Views\Components\Employee\AddEmployee;
use App\Views\Components\Employee\EditEmployee;
use App\Views\Components\Employee\ListEmployee;
use App\Views\Components\Employee\DeleteEmployee;

use App\Views\Components\Department\AddDepartment;
use App\Views\Components\Department\ListDepartment;
use App\Views\Components\Department\EditDepartment;
use App\Views\Components\Department\DeleteDepartment;

use App\Views\Components\Account\Account;

use App\Views\Components\Search\Search;


Header::render();

// Sidebar::render();


// ?? '' : la toan tu cho phep minh tim kiem gia tri o phia truoc 
// neu gia tri o phia truoc hop le thi lay gia tri phia truoc
// neu gia tri o phia truoc hop le thi lay gia tri phia truoc

$action = $_GET['act'] ?? '';

switch ($action) {
    case "":
        Home::render();
        break;
    case "home":
        Home::render();
        break;

    case 'danhsachnhanvien':
        // echo"Đã thêm thành công!";
        ListEmployee::render();
        break;
    case 'themnhanvien':
        AddEmployee::render();

        break;
    case 'xulythemnhanvien':
        AddEmployee::handle();
        break;
    case 'updateemployee':
        EditEmployee::render();
        break;
    case 'xulycapnhatnhanvien':
        EditEmployee::handle();
        break;
    case 'deleteemployee':
        DeleteEmployee::handle();
        break;


    case 'danhsachphong':
        ListDepartment::render();
        break;
    case 'themphong':
        AddDepartment::render();
        break;
    case 'xulythemphong':
        AddDepartment::handle();
        break;

    case 'updatedepartment':
        EditDepartment::render();
        break;
    case 'xulycapnhatphong':
        EditDepartment::handle();
        break;

        // case 'deletedepartment':
        //     DeleteDepartment::render();
        //     break;
    case 'deletedepartment':
        DeleteDepartment::handle();
        break;

    case 'search':
        Search::render();
        break;
    case 'searchdata':
        Search::handle();
        break;

    case 'account':
        Account::render();
        break;
    case 'login':
        // echo"Login successfully";
        Account::login();
        break;
    case 'register':
        Account::register();
        break;
    case 'updatePassword':
        // echo"Login successfully";
        Account::updatePassword();
        break;
    case 'updateAccount':
        Account::updateInfo();
        break;
    case "logout":
            session_unset();
            session_destroy();
            header('Location: ?act=account'); 
            exit();

    default:
        echo "<h1>404 Page Not Found</h1>";
        break;
}


Footer::render();
