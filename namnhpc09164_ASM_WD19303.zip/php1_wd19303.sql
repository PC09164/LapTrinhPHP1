-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th6 02, 2024 lúc 09:03 PM
-- Phiên bản máy phục vụ: 10.4.32-MariaDB
-- Phiên bản PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `php1_wd19303`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `pc09164_departments`
--

CREATE TABLE `pc09164_departments` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Đang đổ dữ liệu cho bảng `pc09164_departments`
--

INSERT INTO `pc09164_departments` (`id`, `name`, `status`) VALUES
(16, 'Công nghệ thông tin', 1),
(18, 'Thiết kế đồ họa', 1),
(19, 'Marketing', 1),
(20, 'Kế Toán', 1),
(21, 'Phòng 5', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `pc09164_emplyees`
--

CREATE TABLE `pc09164_emplyees` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `code` varchar(7) NOT NULL,
  `department_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Đang đổ dữ liệu cho bảng `pc09164_emplyees`
--

INSERT INTO `pc09164_emplyees` (`id`, `firstname`, `lastname`, `code`, `department_id`) VALUES
(1, 'Nguyễn ', 'Hoàng Nam', 'PC09164', 0),
(2, 'Nguyễn ', 'Nhật Huy', 'PC09165', 0),
(3, 'Nguyễn ', 'Hoàng Khang', 'PC09166', 0),
(4, 'Lại', 'Quang Thọ', 'PC09167', 0),
(5, 'Trần ', 'Nhựt Linh', 'PC09168', 0),
(12, 'Lê', 'Thành', 'Nam', 1),
(13, '', '', '', 0);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `pc09164_departments`
--
ALTER TABLE `pc09164_departments`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `pc09164_emplyees`
--
ALTER TABLE `pc09164_emplyees`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department_id` (`department_id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `pc09164_departments`
--
ALTER TABLE `pc09164_departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT cho bảng `pc09164_emplyees`
--
ALTER TABLE `pc09164_emplyees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
